Please replace YOUR_POOL_ID inside mine_gram.bat file.

Пожалуйста замените YOUR_POOL_ID в файле mine_gram.bat